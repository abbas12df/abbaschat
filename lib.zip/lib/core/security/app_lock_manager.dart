import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'biometric_service.dart';
import '../../features/settings/services/settings_service.dart';

class AppLockManager extends ConsumerStatefulWidget {
  final Widget child;
  const AppLockManager({super.key, required this.child});

  @override
  ConsumerState<AppLockManager> createState() => _AppLockManagerState();
}

class _AppLockManagerState extends ConsumerState<AppLockManager>
    with WidgetsBindingObserver {
  bool _isLocked = false;
  DateTime? _pausedTime;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    // Check lock on initial load if needed (optional, usually auth wrapper handles clean boot)
    // But for resume logic:
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      // App went to background
      _pausedTime = DateTime.now();

      // Determine if we should lock immediately
      final settings = ref.read(settingsServiceProvider);
      if (settings.appLock) {
        // We set a flag to lock on resume
        // We can't show UI while paused easily.
        // We will handle it on resumed.
      }
    } else if (state == AppLifecycleState.resumed) {
      final settings = ref.read(settingsServiceProvider);
      if (settings.appLock && _pausedTime != null) {
        // Enforce Lock
        _promptBiometrics();
      }
      _pausedTime = null;
    }
  }

  Future<void> _promptBiometrics() async {
    // Prevent multiple overlays
    if (_isLocked) return;

    setState(() => _isLocked = true);

    // Show Covering Screen or just prompt?
    // A covering screen is safer to hide content.
    // For now, we instantly verify.

    final bio = ref.read(biometricServiceProvider);
    bool didAuth = false;

    // Loop until auth is successful or user force closes?
    // Or just once? Usually loops.
    while (!didAuth) {
      didAuth = await bio.authenticate(
        localizedReason: 'مطلوب البصمة لفك القفل',
      );
      if (!didAuth) {
        // User cancelled or failed.
        // We must keep the app locked/blank.
        // Wait a bit before retrying?
        await Future.delayed(const Duration(milliseconds: 500));
      }
    }

    if (mounted) {
      setState(() => _isLocked = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        widget.child,
        if (_isLocked)
          Positioned.fill(
            child: Container(
              color: Theme.of(context).scaffoldBackgroundColor,
              child: const Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.lock, size: 64, color: Colors.grey),
                    SizedBox(height: 16),
                    Text('التطبيق مقفل', style: TextStyle(fontSize: 20)),
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }
}
