import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../repositories/contact_repository.dart';
import '../../chat/models/user_model.dart';

class EditContactScreen extends ConsumerStatefulWidget {
  final Contact? contact; // If editing existing
  final UserModel? userToAdd; // If adding new

  const EditContactScreen({super.key, this.contact, this.userToAdd});

  @override
  ConsumerState<EditContactScreen> createState() => _EditContactScreenState();
}

class _EditContactScreenState extends ConsumerState<EditContactScreen> {
  final _aliasController = TextEditingController();
  final _groupController = TextEditingController();

  late UserModel _targetUser;

  @override
  void initState() {
    super.initState();
    if (widget.contact != null) {
      _targetUser = widget.contact!.user;
      _aliasController.text = widget.contact!.alias ?? '';
      _groupController.text = widget.contact!.group ?? '';
    } else {
      _targetUser = widget.userToAdd!;
      _aliasController.text =
          _targetUser.displayName; // Default to display name
    }
  }

  Future<void> _save() async {
    final alias = _aliasController.text.trim().isEmpty
        ? null
        : _aliasController.text.trim();
    final group = _groupController.text.trim().isEmpty
        ? null
        : _groupController.text.trim();

    try {
      if (widget.contact != null) {
        // Update existing
        await ref
            .read(contactRepositoryProvider)
            .updateContact(_targetUser.uid, alias: alias, group: group);
      } else {
        // Add new
        await ref
            .read(contactRepositoryProvider)
            .addContact(_targetUser.uid, alias: alias, group: group);
      }
      if (mounted) Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('خطأ: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          widget.contact != null ? 'تعديل جهة الاتصال' : 'حفظ جهة الاتصال',
        ),
        actions: [IconButton(icon: const Icon(Icons.check), onPressed: _save)],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            CircleAvatar(
              radius: 40,
              child: Text(
                _targetUser.displayName[0],
                style: const TextStyle(fontSize: 30),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'الاسم الأصلي: ${_targetUser.displayName}',
              style: const TextStyle(color: Colors.grey),
            ),

            const SizedBox(height: 30),

            TextField(
              controller: _aliasController,
              decoration: const InputDecoration(
                labelText: 'الاسم (Alias)',
                helperText: 'اسم يظهر لك فقط',
                prefixIcon: Icon(Icons.edit),
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _groupController,
              decoration: const InputDecoration(
                labelText: 'المجموعة (اختياري)',
                helperText: 'مثال: العائلة، العمل',
                prefixIcon: Icon(Icons.group_work),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
