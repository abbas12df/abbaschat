import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../chat/screens/chat_screen.dart';
import '../repositories/contact_repository.dart';
import 'add_contact_screen.dart';
import 'edit_contact_screen.dart';

class ContactsScreen extends ConsumerStatefulWidget {
  const ContactsScreen({super.key});

  @override
  ConsumerState<ContactsScreen> createState() => _ContactsScreenState();
}

class _ContactsScreenState extends ConsumerState<ContactsScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _searchController.addListener(() {
      setState(
        () => _searchQuery = _searchController.text.trim().toLowerCase(),
      );
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // 1. Fetch Contacts Stream
    final contactStream = StreamBuilder<List<Contact>>(
      stream: ref.watch(contactRepositoryProvider).watchContacts(),
      builder: (context, snapshot) {
        if (snapshot.hasError)
          return Center(child: Text('خطأ: ${snapshot.error}'));
        if (!snapshot.hasData)
          return const Center(child: CircularProgressIndicator());

        var contacts = snapshot.data!;

        // 2. Local Filter
        if (_searchQuery.isNotEmpty) {
          contacts = contacts.where((c) {
            final name = c.displayName.toLowerCase();
            final phone = c.user.phoneNumber?.toLowerCase() ?? '';
            final username = c.user.username?.toLowerCase() ?? '';
            return name.contains(_searchQuery) ||
                phone.contains(_searchQuery) ||
                username.contains(_searchQuery);
          }).toList();
        }

        if (contacts.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.people_outline,
                  size: 60,
                  color: Theme.of(context).iconTheme.color ?? Colors.grey,
                ),
                const SizedBox(height: 16),
                Text(
                  _searchQuery.isEmpty
                      ? 'لا توجد جهات اتصال بعد'
                      : 'لا توجد نتائج',
                  style: const TextStyle(color: Colors.grey, fontSize: 16),
                ),
                if (_searchQuery.isEmpty)
                  TextButton(
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const AddContactScreen(),
                      ),
                    ),
                    child: const Text('إضافة جهة اتصال جديدة'),
                  ),
              ],
            ),
          );
        }

        return ListView.separated(
          itemCount: contacts.length,
          separatorBuilder: (_, __) => const Divider(height: 1, indent: 70),
          itemBuilder: (context, index) {
            final contact = contacts[index];
            return ListTile(
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 8,
              ),
              leading: Stack(
                children: [
                  CircleAvatar(
                    radius: 28,
                    backgroundImage: _getImageProvider(contact.user.photoURL),
                    child: contact.user.photoURL == null
                        ? Text(
                            contact.displayName[0].toUpperCase(),
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 20,
                            ),
                          )
                        : null,
                  ),
                  if (contact.user.isOnline)
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: Container(
                        padding: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          color: Theme.of(context).scaffoldBackgroundColor,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.circle,
                          color: Colors.green,
                          size: 12,
                        ),
                      ),
                    ),
                ],
              ),
              title: Text(
                contact.displayName,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                contact.user.bio ?? contact.user.username ?? 'لا توجد حالة',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              trailing: contact.group != null
                  ? Chip(
                      label: Text(
                        contact.group!,
                        style: const TextStyle(fontSize: 10),
                      ),
                    )
                  : null,
              onTap: () {
                // Navigate to Chat
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ChatScreen(
                      userName: contact.displayName,
                      otherUserId: contact.user.uid,
                    ),
                  ),
                );
              },
              onLongPress: () {
                // Edit/Delete
                showModalBottomSheet(
                  context: context,
                  builder: (_) => _buildOptionsSheet(context, contact),
                );
              },
            );
          },
        );
      },
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text('جهات الاتصال'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'بحث في جهات الاتصال...',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: Theme.of(context).cardColor,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
        ),
      ),
      body: contactStream,
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const AddContactScreen()),
        ),
        child: const Icon(Icons.person_add),
      ),
    );
  }

  Widget _buildOptionsSheet(BuildContext context, Contact contact) {
    return Container(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.edit),
            title: const Text('تعديل الاسم أو المجموعة'),
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => EditContactScreen(contact: contact),
                ),
              );
            },
          ),
          ListTile(
            leading: const Icon(Icons.delete, color: Colors.red),
            title: const Text(
              'حذف جهة الاتصال',
              style: TextStyle(color: Colors.red),
            ),
            onTap: () {
              Navigator.pop(context);
              _confirmDelete(context, contact);
            },
          ),
        ],
      ),
    );
  }

  void _confirmDelete(BuildContext context, Contact contact) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('حذف جهة الاتصال؟'),
        content: Text(
          'هل أنت متأكد من حذف "${contact.displayName}" من جهات الاتصال؟',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          TextButton(
            onPressed: () async {
              await ref
                  .read(contactRepositoryProvider)
                  .removeContact(contact.user.uid);
              if (mounted) Navigator.pop(context);
            },
            child: const Text('حذف', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  ImageProvider? _getImageProvider(String? url) {
    // ... Implement logic similar to other screens
    return null; // Placeholder for brevity, reused commonly
  }
}
