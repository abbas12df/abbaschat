import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'account_settings_screen.dart';
import 'privacy_settings_screen.dart';
import 'security_settings_screen.dart';
import 'storage_settings_screen.dart';
import 'notifications_settings_screen.dart';
import 'appearance_settings_screen.dart';
// import 'about_screen.dart'; // TODO

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text('الإعدادات'),
        centerTitle: true,
        elevation: 0,
        backgroundColor: theme.scaffoldBackgroundColor,
        foregroundColor: theme.textTheme.bodyLarge?.color,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildHashtagHeader(context, 'الحساب'),
          _buildSettingsTile(
            context,
            icon: Icons.person_outline,
            title: 'الحساب',
            subtitle: 'البريد الإلكتروني، كلمة المرور، حذف الحساب',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AccountSettingsScreen()),
            ),
          ),

          const SizedBox(height: 24),
          _buildHashtagHeader(context, 'الخصوصية والأمان'),
          _buildSettingsTile(
            context,
            icon: Icons.lock_outline,
            title: 'الخصوصية',
            subtitle: 'حالة الاتصال، مؤشر الكتابة، إيصالات القراءة',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const PrivacySettingsScreen()),
            ),
          ),
          _buildSettingsTile(
            context,
            icon: Icons.shield_outlined,
            title: 'الأمان',
            subtitle: 'قفل التطبيق، تأكيد الهوية',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SecuritySettingsScreen()),
            ),
          ),

          const SizedBox(height: 24),
          _buildHashtagHeader(context, 'البيانات'),
          _buildSettingsTile(
            context,
            icon: Icons.storage_outlined,
            title: 'التخزين والبيانات',
            subtitle: 'إدارة المساحة، حذف الرسائل',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const StorageSettingsScreen()),
            ),
          ),

          const SizedBox(height: 24),
          _buildHashtagHeader(context, 'التطبيق'),
          _buildSettingsTile(
            context,
            icon: Icons.notifications_none,
            title: 'الإشعارات',
            subtitle: 'الرسائل، الأصوات',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const NotificationsSettingsScreen(),
                ),
              );
            },
          ),
          _buildSettingsTile(
            context,
            icon: Icons.palette_outlined,
            title: 'المظهر',
            subtitle: 'الوضع الداكن، الفاتح، التلقائي',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const AppearanceSettingsScreen(),
                ),
              );
            },
          ),
          _buildSettingsTile(
            context,
            icon: Icons.info_outline,
            title: 'حول التطبيق',
            subtitle: 'الإصدار، الشروط، سياسة الخصوصية',
            onTap: () {
              // TODO: Navigate to AboutScreen
              ScaffoldMessenger.of(
                context,
              ).showSnackBar(const SnackBar(content: Text('قريباً...')));
            },
          ),
        ],
      ).animate().fadeIn(),
    );
  }

  Widget _buildHashtagHeader(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8, right: 4),
      child: Text(
        title,
        style: TextStyle(color: Theme.of(context).textTheme.bodySmall?.color),
      ),
    );
  }

  Widget _buildSettingsTile(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: Theme.of(context).dividerColor),
      ),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Theme.of(context).primaryColor.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: Theme.of(context).iconTheme.color),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
        trailing: Icon(
          Icons.arrow_forward_ios,
          size: 14,
          color: Theme.of(context).iconTheme.color,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        onTap: onTap,
      ),
    );
  }
}
