import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/local/local_storage_service.dart';
import 'package:firebase_auth/firebase_auth.dart';

final settingsServiceProvider = Provider<SettingsService>((ref) {
  return SettingsService(ref.read(localStorageServiceProvider));
});

class SettingsService {
  final LocalStorageService _local;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  SettingsService(this._local);

  String? get _uid => _auth.currentUser?.uid;

  Future<void> init() async {
    if (_uid != null) {
      await _local.openUserBox(_uid!);
    }
  }

  // --- Generic Helpers ---
  Future<void> _setBool(String key, bool value) async {
    if (_uid == null) return;
    await _local.saveUserSetting(_uid!, key, value);
  }

  bool _getBool(String key, {bool defaultValue = false}) {
    if (_uid == null) return defaultValue;
    final val = _local.getUserSetting(_uid!, key);
    return val is bool ? val : defaultValue;
  }

  // --- Privacy ---
  Future<void> setOnlineStatus(bool value) =>
      _setBool('privacy_online_status', value);
  bool get onlineStatus =>
      _getBool('privacy_online_status', defaultValue: true);

  Future<void> setTypingIndicator(bool value) =>
      _setBool('privacy_typing', value);
  bool get typingIndicator => _getBool('privacy_typing', defaultValue: true);

  Future<void> setReadReceipts(bool value) =>
      _setBool('privacy_read_receipts', value);
  bool get readReceipts =>
      _getBool('privacy_read_receipts', defaultValue: true);

  // --- Security ---
  Future<void> setAppLock(bool value) => _setBool('security_app_lock', value);
  bool get appLock => _getBool('security_app_lock', defaultValue: false);

  // --- Appearance ---
  Future<void> setThemeMode(String value) =>
      _local.saveUserSetting(_uid!, 'appearance_theme_mode', value);

  String get themeMode {
    if (_uid == null) return 'system';
    return _local.getUserSetting(_uid!, 'appearance_theme_mode') as String? ??
        'system';
  }

  // --- Notifications ---
  Future<void> setNotificationsEnabled(bool value) =>
      _setBool('notifications_enabled', value);
  bool get notificationsEnabled =>
      _getBool('notifications_enabled', defaultValue: true);

  Future<void> setNotificationSound(bool value) =>
      _setBool('notifications_sound', value);
  bool get notificationSound =>
      _getBool('notifications_sound', defaultValue: true);

  Future<void> setNotificationVibrate(bool value) =>
      _setBool('notifications_vibrate', value);
  bool get notificationVibrate =>
      _getBool('notifications_vibrate', defaultValue: true);

  Future<void> setNotificationPreview(bool value) =>
      _setBool('notifications_preview', value);
  bool get notificationPreview =>
      _getBool('notifications_preview', defaultValue: true);
}
