import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'dart:async';

class VoiceMessagePlayer extends StatefulWidget {
  final String audioUrl;
  final Duration? duration;
  final bool isMe;
  final Function(String url)? onPlay;

  const VoiceMessagePlayer({
    super.key,
    required this.audioUrl,
    this.duration,
    required this.isMe,
    this.onPlay,
  });

  @override
  State<VoiceMessagePlayer> createState() => _VoiceMessagePlayerState();
}

class _VoiceMessagePlayerState extends State<VoiceMessagePlayer> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isPlaying = false;
  Duration _currentPosition = Duration.zero;
  Duration _totalDuration = Duration.zero;
  StreamSubscription? _positionSubscription;
  StreamSubscription? _durationSubscription;
  StreamSubscription? _stateSubscription;

  @override
  void initState() {
    super.initState();
    _initializePlayer();
  }

  void _initializePlayer() {
    // Listen to position changes
    _positionSubscription = _audioPlayer.onPositionChanged.listen((position) {
      if (mounted) {
        setState(() {
          _currentPosition = position;
        });
      }
    });

    // Listen to duration changes
    _durationSubscription = _audioPlayer.onDurationChanged.listen((duration) {
      if (mounted) {
        setState(() {
          _totalDuration = duration;
        });
      }
    });

    // Listen to player state changes
    _stateSubscription = _audioPlayer.onPlayerComplete.listen((_) {
      if (mounted) {
        setState(() {
          _isPlaying = false;
          _currentPosition = Duration.zero;
        });
      }
    });

    // Set initial duration if provided
    if (widget.duration != null) {
      _totalDuration = widget.duration!;
    }
  }

  Future<void> _togglePlay() async {
    if (_isPlaying) {
      await _audioPlayer.pause();
      setState(() => _isPlaying = false);
    } else {
      // Notify parent that we're playing
      widget.onPlay?.call(widget.audioUrl);

      await _audioPlayer.play(
        widget.audioUrl.startsWith('/')
            ? DeviceFileSource(widget.audioUrl)
            : UrlSource(widget.audioUrl),
      );
      setState(() => _isPlaying = true);
    }
  }

  @override
  void dispose() {
    _positionSubscription?.cancel();
    _durationSubscription?.cancel();
    _stateSubscription?.cancel();
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      constraints: const BoxConstraints(maxWidth: 250, minWidth: 180),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildPlayButton(),
          const SizedBox(width: 8),
          Expanded(child: _buildWaveform()),
          const SizedBox(width: 8),
          _buildDuration(),
        ],
      ),
    );
  }

  Widget _buildPlayButton() {
    return GestureDetector(
      onTap: _togglePlay,
      child: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: widget.isMe
              ? Colors.white.withValues(alpha: 0.3)
              : Colors.blue.withValues(alpha: 0.2),
          shape: BoxShape.circle,
        ),
        child: Icon(
          _isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
          color: widget.isMe ? Colors.white : Colors.blue,
          size: 20,
        ),
      ),
    );
  }

  Widget _buildWaveform() {
    final progress = _totalDuration.inMilliseconds > 0
        ? _currentPosition.inMilliseconds / _totalDuration.inMilliseconds
        : 0.0;

    return SizedBox(
      height: 24,
      child: CustomPaint(
        painter: WaveformPainter(
          progress: progress.clamp(0.0, 1.0),
          color: widget.isMe ? Colors.white : Colors.blue,
          activeColor: widget.isMe ? Colors.white : Colors.blue[700]!,
        ),
      ),
    );
  }

  Widget _buildDuration() {
    final displayDuration = _isPlaying ? _currentPosition : _totalDuration;

    return Text(
      _formatDuration(displayDuration),
      style: TextStyle(
        fontSize: 11,
        fontFamily: 'monospace',
        color: widget.isMe ? Colors.white70 : Colors.black54,
      ),
    );
  }

  String _formatDuration(Duration d) {
    if (d == Duration.zero) return "0:00";
    String twoDigits(int n) => n.toString().padLeft(2, "0");
    String twoDigitSeconds = twoDigits(d.inSeconds.remainder(60));
    return "${d.inMinutes}:$twoDigitSeconds";
  }
}

class WaveformPainter extends CustomPainter {
  final double progress;
  final Color color;
  final Color activeColor;

  WaveformPainter({
    required this.progress,
    required this.color,
    required this.activeColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final inactivePaint = Paint()
      ..color = color.withValues(alpha: 0.3)
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;

    final activePaint = Paint()
      ..color = activeColor
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;

    // Generate waveform bars (20 bars)
    const barCount = 20;
    final barWidth = size.width / barCount;

    // Predefined heights for aesthetic waveform
    const heights = [
      0.3,
      0.7,
      0.5,
      0.9,
      0.6,
      0.4,
      0.8,
      0.5,
      0.7,
      0.6,
      0.4,
      0.8,
      0.6,
      0.5,
      0.9,
      0.4,
      0.7,
      0.5,
      0.6,
      0.8,
    ];

    for (int i = 0; i < barCount; i++) {
      final x = i * barWidth + barWidth / 2;
      final height = size.height * heights[i % heights.length];
      final isActive = (i / barCount) < progress;

      canvas.drawLine(
        Offset(x, size.height / 2 - height / 2),
        Offset(x, size.height / 2 + height / 2),
        isActive ? activePaint : inactivePaint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant WaveformPainter oldDelegate) {
    return oldDelegate.progress != progress;
  }
}
