import 'package:cloud_firestore/cloud_firestore.dart';

class ChatRoom {
  final String id;
  final List<String> participants;
  final String lastMessage;
  final DateTime lastMessageTime;
  final Map<String, int> unreadCounts;
  final bool isGroup;
  final String? groupName;
  final String? groupIcon;
  final String? description; // Added
  final List<String>? admins;
  final List<String> deletedBy;
  final bool isPublic; // New
  final bool onlyAdminsCanPost; // New
  final List<String> pendingRequests; // New
  final String? groupHandle; // New (@handle)
  final String? createdBy; // New: Owner ID
  final Map<String, List<String>>?
  adminPermissions; // New: {adminId: [perm1, perm2]}

  ChatRoom({
    required this.id,
    required this.participants,
    required this.lastMessage,
    required this.lastMessageTime,
    required this.unreadCounts,
    this.isGroup = false,
    this.groupName,
    this.groupIcon,
    this.description,
    this.admins,
    this.deletedBy = const [],
    this.isPublic = false,
    this.onlyAdminsCanPost = false,
    this.pendingRequests = const [],
    this.groupHandle,
    this.createdBy,
    this.adminPermissions,
  });

  Map<String, dynamic> toMap() {
    return {
      'participants': participants,
      'lastMessage': lastMessage,
      'lastMessageTime': lastMessageTime.millisecondsSinceEpoch,
      'unreadCounts': unreadCounts,
      'isGroup': isGroup,
      'groupName': groupName,
      'groupIcon': groupIcon,
      'description': description,
      'admins': admins,
      'deletedBy': deletedBy,
      'isPublic': isPublic,
      'onlyAdminsCanPost': onlyAdminsCanPost,
      'pendingRequests': pendingRequests,
      'groupHandle': groupHandle,
      'createdBy': createdBy,
      'adminPermissions': adminPermissions,
    };
  }

  factory ChatRoom.fromMap(String id, Map<String, dynamic> map) {
    return ChatRoom(
      id: id,
      participants: List<String>.from(map['participants'] ?? []),
      lastMessage: map['lastMessage'] ?? '',
      lastMessageTime: map['lastMessageTime'] is int
          ? DateTime.fromMillisecondsSinceEpoch(map['lastMessageTime'] as int)
          : (map['lastMessageTime'] is Timestamp
                ? (map['lastMessageTime'] as Timestamp).toDate()
                : DateTime.now()),
      unreadCounts:
          (map['unreadCounts'] as Map?)?.map(
            (key, value) => MapEntry(key.toString(), (value as num).toInt()),
          ) ??
          {},
      isGroup: map['isGroup'] ?? false,
      groupName: map['groupName'],
      groupIcon: map['groupIcon'],
      description: map['description'],
      admins: map['admins'] != null ? List<String>.from(map['admins']) : null,
      deletedBy: map['deletedBy'] != null
          ? List<String>.from(map['deletedBy'])
          : [],
      // New fields
      isPublic: map['isPublic'] ?? false,
      onlyAdminsCanPost: map['onlyAdminsCanPost'] ?? false,
      pendingRequests: map['pendingRequests'] != null
          ? List<String>.from(map['pendingRequests'])
          : [],
      groupHandle: map['groupHandle'],
      createdBy: map['createdBy'],
      adminPermissions: (map['adminPermissions'] as Map?)?.map(
        (key, value) =>
            MapEntry(key.toString(), List<String>.from(value ?? [])),
      ),
    );
  }
}
