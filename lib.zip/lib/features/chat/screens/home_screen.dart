import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'dart:async';
import '../../chat/repositories/chat_repository.dart';
import '../../chat/models/user_model.dart';
import 'search_user_screen.dart';
import 'chat_screen.dart';
import '../../profile/screens/profile_screen.dart';
import 'create_group_screen.dart';
import '../../../core/widgets/connection_status_bar.dart';
import '../widgets/avatar_with_presence.dart';
import '../widgets/unread_badge.dart';
import '../widgets/message_preview.dart';
import '../widgets/chat_list_skeleton.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  @override
  void initState() {
    super.initState();
    // Schedule active chat restoration after first frame
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(chatRepositoryProvider).restoreActiveChats();
    });
  }

  @override
  Widget build(BuildContext context) {
    // Listener moved to NotificationWatcher for global access
    final chatsAsync = ref.watch(userChatsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Q-Chat'),
        leading: Padding(
          padding: const EdgeInsets.all(8.0),
          child: InkWell(
            onTap: () {
              Navigator.of(
                context,
              ).push(MaterialPageRoute(builder: (_) => const ProfileScreen()));
            },
            child: CircleAvatar(
              backgroundColor: Theme.of(context).colorScheme.secondary,
              child: Icon(
                Icons.person,
                color: Theme.of(context).colorScheme.onPrimary,
              ),
            ),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const SearchUserScreen()),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          const ConnectionStatusBar(),
          Expanded(
            child: chatsAsync.when(
              data: (chats) {
                if (chats.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                              padding: const EdgeInsets.all(24),
                              decoration: BoxDecoration(
                                color: Theme.of(context)
                                    .colorScheme
                                    .primaryContainer
                                    .withValues(alpha: 0.3),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                Icons.chat_bubble_outline_rounded,
                                size: 64,
                                color: Theme.of(context).colorScheme.primary,
                              ),
                            )
                            .animate()
                            .fadeIn(duration: 600.ms)
                            .scale(delay: 200.ms, curve: Curves.easeOutBack),
                        const SizedBox(height: 24),
                        Text(
                          'لا توجد محادثات بعد',
                          style: Theme.of(context).textTheme.titleLarge
                              ?.copyWith(fontWeight: FontWeight.w600),
                        ).animate().fadeIn(delay: 400.ms),
                        const SizedBox(height: 8),
                        Text(
                          'ابدأ محادثة جديدة مع أصدقائك',
                          style: Theme.of(context).textTheme.bodyMedium
                              ?.copyWith(
                                color: Theme.of(
                                  context,
                                ).textTheme.bodySmall?.color,
                              ),
                          textAlign: TextAlign.center,
                        ).animate().fadeIn(delay: 500.ms),
                        const SizedBox(height: 32),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            ElevatedButton.icon(
                                  onPressed: () {
                                    Navigator.of(context).push(
                                      MaterialPageRoute(
                                        builder: (_) =>
                                            const SearchUserScreen(),
                                      ),
                                    );
                                  },
                                  icon: const Icon(Icons.person_add_outlined),
                                  label: const Text('ابحث عن صديق'),
                                  style: ElevatedButton.styleFrom(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 24,
                                      vertical: 12,
                                    ),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                  ),
                                )
                                .animate()
                                .fadeIn(delay: 600.ms)
                                .slideY(begin: 0.2, curve: Curves.easeOut),
                            const SizedBox(width: 12),
                            OutlinedButton.icon(
                                  onPressed: () {
                                    Navigator.of(context).push(
                                      MaterialPageRoute(
                                        builder: (_) =>
                                            const CreateGroupScreen(),
                                      ),
                                    );
                                  },
                                  icon: const Icon(Icons.group_add_outlined),
                                  label: const Text('مجموعة جديدة'),
                                  style: OutlinedButton.styleFrom(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 24,
                                      vertical: 12,
                                    ),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                  ),
                                )
                                .animate()
                                .fadeIn(delay: 700.ms)
                                .slideY(begin: 0.2, curve: Curves.easeOut),
                          ],
                        ),
                      ],
                    ),
                  );
                }
                return ListView.builder(
                  itemCount: chats.length,
                  padding: const EdgeInsets.only(top: 8),
                  itemBuilder: (context, index) {
                    final chat = chats[index];
                    final currentUserId =
                        FirebaseAuth.instance.currentUser?.uid;
                    if (chat.isGroup) {
                      final groupName = chat.groupName ?? 'مجموعة';
                      final groupIcon = chat.groupIcon;

                      return Dismissible(
                        key: Key(chat.id),
                        direction: DismissDirection.endToStart,
                        background: _buildDismissBackground(context),
                        confirmDismiss: (direction) =>
                            _confirmDelete(context, ref, chat.id, chat.isGroup),
                        onDismissed: (direction) {
                          ref.read(chatRepositoryProvider).deleteChat(chat.id);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('تم حذف المجموعة')),
                          );
                        },
                        child: Material(
                          color: Colors.transparent,
                          child: InkWell(
                            onTap: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => ChatScreen(
                                    userName: groupName,
                                    otherUserId: chat.id,
                                    isGroup: true,
                                  ),
                                ),
                              );
                            },
                            borderRadius: BorderRadius.circular(12),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 12,
                              ),
                              child: Row(
                                children: [
                                  AvatarWithPresence(
                                    imageUrl: groupIcon,
                                    fallbackText: groupName,
                                    isGroup: true,
                                    radius: 28,
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          groupName,
                                          style: Theme.of(context)
                                              .textTheme
                                              .titleMedium
                                              ?.copyWith(
                                                fontWeight: FontWeight.w600,
                                                fontSize: 16,
                                              ),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        const SizedBox(height: 4),
                                        MessagePreview(
                                          content: chat.lastMessage,
                                          isUnread:
                                              (chat.unreadCounts[currentUserId] ??
                                                  0) >
                                              0,
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Text(
                                        _formatTime(chat.lastMessageTime),
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodySmall
                                            ?.copyWith(fontSize: 12),
                                      ),
                                      const SizedBox(height: 4),
                                      UnreadBadge(
                                        count:
                                            chat.unreadCounts[currentUserId] ??
                                            0,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ).animate().fadeIn(delay: (index * 50).ms).slideX();
                    }

                    // 1-on-1 Chat Logic
                    final otherUserId = chat.participants.firstWhere(
                      (id) => id != currentUserId,
                      orElse: () => 'Unknown',
                    );

                    return FutureBuilder<UserModel?>(
                      future: ref
                          .read(chatRepositoryProvider)
                          .getUserData(otherUserId),
                      builder: (context, snapshot) {
                        final user = snapshot.data;
                        final displayName = user?.displayName ?? 'مستخدم';

                        return Dismissible(
                          key: Key(chat.id),
                          direction: DismissDirection.endToStart,
                          background: _buildDismissBackground(context),
                          confirmDismiss: (direction) =>
                              _confirmDelete(context, ref, chat.id, false),
                          onDismissed: (direction) {
                            ref
                                .read(chatRepositoryProvider)
                                .deleteChat(chat.id);
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('تم حذف المحادثة')),
                            );
                          },
                          child: StreamBuilder<Map<String, dynamic>>(
                            stream: ref
                                .watch(chatRepositoryProvider)
                                .getUserPresence(otherUserId),
                            builder: (context, presenceSnapshot) {
                              final isOnline =
                                  presenceSnapshot.data?['state'] == 'online';

                              return Material(
                                color: Colors.transparent,
                                child: InkWell(
                                  onTap: () {
                                    Navigator.of(context).push(
                                      MaterialPageRoute(
                                        builder: (_) => ChatScreen(
                                          userName: displayName,
                                          otherUserId: otherUserId,
                                          isGroup: false,
                                        ),
                                      ),
                                    );
                                  },
                                  borderRadius: BorderRadius.circular(12),
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 16,
                                      vertical: 12,
                                    ),
                                    child: Row(
                                      children: [
                                        AvatarWithPresence(
                                          imageUrl: user?.photoURL,
                                          fallbackText: displayName,
                                          backgroundColor: Colors
                                              .primaries[index %
                                                  Colors.primaries.length]
                                              .shade100,
                                          isOnline: isOnline,
                                          radius: 28,
                                        ),
                                        const SizedBox(width: 12),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                displayName,
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .titleMedium
                                                    ?.copyWith(
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      fontSize: 16,
                                                    ),
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                              const SizedBox(height: 4),
                                              MessagePreview(
                                                content: chat.lastMessage,
                                                isUnread:
                                                    (chat.unreadCounts[currentUserId] ??
                                                        0) >
                                                    0,
                                              ),
                                            ],
                                          ),
                                        ),
                                        const SizedBox(width: 12),
                                        Column(
                                          mainAxisSize: MainAxisSize.min,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.end,
                                          children: [
                                            Text(
                                              _formatTime(chat.lastMessageTime),
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .bodySmall
                                                  ?.copyWith(fontSize: 12),
                                            ),
                                            const SizedBox(height: 4),
                                            UnreadBadge(
                                              count:
                                                  chat.unreadCounts[currentUserId] ??
                                                  0,
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ).animate().fadeIn(delay: (index * 50).ms).slideX();
                      },
                    );
                  },
                );
              },
              error: (err, stack) => _AutoRetryErrorWidget(
                onRetry: () => ref.invalidate(userChatsProvider),
              ),
              loading: () => const ChatListSkeleton(),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showModalBottomSheet(
            context: context,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            builder: (ctx) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Theme.of(context).primaryColor,
                      child: Icon(
                        Icons.person,
                        color: Theme.of(context).colorScheme.onPrimary,
                      ),
                    ),
                    title: const Text('محادثة خاصة'),
                    onTap: () {
                      Navigator.pop(ctx);
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => const SearchUserScreen(),
                        ),
                      );
                    },
                  ),
                  const Divider(),
                  ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Theme.of(context).colorScheme.secondary,
                      child: Icon(
                        Icons.group,
                        color: Theme.of(context).colorScheme.onPrimary,
                      ),
                    ),
                    title: const Text('مجموعة جديدة'),
                    onTap: () {
                      Navigator.pop(ctx);
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => const CreateGroupScreen(),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          );
        },
        backgroundColor: Theme.of(context).colorScheme.primary,
        child: Icon(
          Icons.add_comment_rounded,
          color: Theme.of(context).colorScheme.onPrimary,
        ),
      ).animate().scale(delay: 500.ms),
    );
  }

  Widget _buildDismissBackground(BuildContext context) {
    return Container(
      alignment: Alignment.centerLeft,
      padding: const EdgeInsets.only(left: 20),
      color: Theme.of(context).colorScheme.error,
      child: Icon(Icons.delete, color: Theme.of(context).colorScheme.onError),
    );
  }

  Future<bool?> _confirmDelete(
    BuildContext context,
    WidgetRef ref,
    String roomId,
    bool isGroup,
  ) async {
    if (isGroup) {
      // --- GROUP LOGIC: Leave or Delete Local Only ---
      return await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('مغادرة المجموعة؟'),
          content: const Text(
            'سيتم حذف النسخة المحلية من المحادثة. إذا كنت عضواً، ستغادر المجموعة.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: const Text('إلغاء'),
            ),
            TextButton(
              onPressed: () async {
                await ref.read(chatRepositoryProvider).leaveGroup(roomId);
                if (ctx.mounted) Navigator.of(ctx).pop(true);
              },
              style: TextButton.styleFrom(
                foregroundColor: Theme.of(context).colorScheme.error,
              ),
              child: const Text('مغادرة وحذف'),
            ),
          ],
        ),
      );
    } else {
      // --- PRIVATE CHAT LOGIC ---
      final result = await showModalBottomSheet<String>(
        context: context,
        backgroundColor: Colors.transparent,
        builder: (ctx) => Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Theme.of(context).scaffoldBackgroundColor,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.warning_amber_rounded,
                size: 48,
                color: Theme.of(context).colorScheme.error,
              ),
              const SizedBox(height: 16),
              const Text(
                'حذف المحادثة؟',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text(
                'يمكنك حذف المحادثة من عندك فقط، أو حذفها من الطرفين.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.of(ctx).pop('me'),
                      child: const Text('حذف عندي فقط'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.of(ctx).pop('everyone'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).colorScheme.error,
                    foregroundColor: Theme.of(context).colorScheme.onError,
                  ),
                  child: const Text('حذف من الطرفين'),
                ),
              ),
              const SizedBox(height: 12),
              TextButton(
                onPressed: () => Navigator.of(ctx).pop('cancel'),
                child: const Text('إلغاء'),
              ),
            ],
          ),
        ),
      );

      if (result == 'me') {
        return true; // Local delete handled by Dismissible
      } else if (result == 'everyone') {
        if (context.mounted) {
          await _deleteForEveryone(context, ref, roomId);
        }
        return false; // Don't trigger standard dismiss, logic handled above.
      }
      return false;
    }
  }

  Future<void> _deleteForEveryone(
    BuildContext context,
    WidgetRef ref,
    String roomId,
  ) async {
    try {
      // 1. Send Command
      await ref
          .read(chatRepositoryProvider)
          .deleteConversationForEveryone(roomId);

      // 2. Show success
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم حذف المحادثة من الطرفين بنجاح')),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('فشل الحذف من الطرفين: $e')));
      }
    }
  }

  String _formatTime(DateTime time) {
    final now = DateTime.now();
    if (now.day == time.day &&
        now.month == time.month &&
        now.year == time.year) {
      return "${time.hour > 12 ? time.hour - 12 : (time.hour == 0 ? 12 : time.hour)}:${time.minute.toString().padLeft(2, '0')} ${time.hour >= 12 ? 'PM' : 'AM'}";
    } else {
      return "${time.day}/${time.month}";
    }
  }
}

// Auto-retry error widget with countdown
class _AutoRetryErrorWidget extends StatefulWidget {
  final VoidCallback onRetry;

  const _AutoRetryErrorWidget({required this.onRetry});

  @override
  State<_AutoRetryErrorWidget> createState() => _AutoRetryErrorWidgetState();
}

class _AutoRetryErrorWidgetState extends State<_AutoRetryErrorWidget> {
  int _countdown = 3;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _startCountdown();
  }

  void _startCountdown() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_countdown > 0) {
        setState(() {
          _countdown--;
        });
      } else {
        timer.cancel();
        widget.onRetry();
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
                Icons.cloud_off_outlined,
                size: 80,
                color: Theme.of(context).iconTheme.color,
              )
              .animate(onPlay: (c) => c.repeat(reverse: true))
              .fadeIn(duration: 1000.ms)
              .then()
              .fadeOut(duration: 1000.ms),
          const SizedBox(height: 24),
          const Text(
            'يتم تحميل المحادثات...',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            'إعادة المحاولة خلال $_countdown ثواني',
            style: TextStyle(
              fontSize: 14,
              color: Theme.of(context).textTheme.bodySmall?.color,
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: 40,
            height: 40,
            child: CircularProgressIndicator(
              value: _countdown / 3,
              strokeWidth: 3,
            ),
          ),
          const SizedBox(height: 24),
          TextButton.icon(
            onPressed: () {
              _timer?.cancel();
              widget.onRetry();
            },
            icon: const Icon(Icons.refresh),
            label: const Text('إعادة المحاولة الآن'),
          ),
        ],
      ),
    );
  }
}
