import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../repositories/chat_repository.dart';

class AddGroupMembersScreen extends ConsumerStatefulWidget {
  final String roomId;
  final List<String> currentMemberIds;

  const AddGroupMembersScreen({
    super.key,
    required this.roomId,
    required this.currentMemberIds,
  });

  @override
  ConsumerState<AddGroupMembersScreen> createState() =>
      _AddGroupMembersScreenState();
}

class _AddGroupMembersScreenState extends ConsumerState<AddGroupMembersScreen> {
  final _searchController = TextEditingController();
  final Set<String> _selectedUserIds = {};
  List<Map<String, dynamic>> _searchResults = [];
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    if (_searchController.text.trim().isEmpty) {
      setState(() => _searchResults = []);
      return;
    }
    _performSearch(_searchController.text.trim());
  }

  Future<void> _performSearch(String query) async {
    final snapshot = await FirebaseFirestore.instance
        .collection('users')
        .where('displayName', isGreaterThanOrEqualTo: query)
        .where('displayName', isLessThan: query + 'z')
        .limit(20)
        .get();

    final currentUid = FirebaseAuth.instance.currentUser?.uid;

    if (mounted) {
      setState(() {
        _searchResults = snapshot.docs
            .map((doc) => doc.data())
            .where(
              (data) =>
                  data['uid'] != currentUid &&
                  !widget.currentMemberIds.contains(
                    data['uid'],
                  ), // Filter existing members
            )
            .toList();
      });
    }
  }

  Future<void> _addMembers() async {
    if (_selectedUserIds.isEmpty) return;

    setState(() => _isLoading = true);

    try {
      await ref
          .read(chatRepositoryProvider)
          .addGroupMembers(widget.roomId, _selectedUserIds.toList());

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم إضافة الأعضاء بنجاح ✅')),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('خطأ: $e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final primaryColor = theme.primaryColor;

    return Scaffold(
      appBar: AppBar(
        title: const Text('إضافة أعضاء'),
        actions: [
          TextButton(
            onPressed: (_isLoading || _selectedUserIds.isEmpty)
                ? null
                : _addMembers,
            child: _isLoading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : Text(
                    'إضافة (${_selectedUserIds.length})',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: _selectedUserIds.isEmpty
                          ? theme.disabledColor
                          : primaryColor,
                    ),
                  ),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.search),
                hintText: 'ابحث عن اسم...',
                filled: true,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _searchResults.length,
              itemBuilder: (context, index) {
                final user = _searchResults[index];
                final uid = user['uid'];
                final isSelected = _selectedUserIds.contains(uid);

                return ListTile(
                  leading: CircleAvatar(
                    backgroundImage:
                        user['photoURL'] != null &&
                            (user['photoURL'] as String).startsWith('http')
                        ? NetworkImage(user['photoURL'])
                        : null,
                    child: user['photoURL'] == null
                        ? const Icon(Icons.person)
                        : null,
                  ),
                  title: Text(
                    user['displayName'] ?? 'مستخدم',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text('@${user['username'] ?? ''}'),
                  trailing: Checkbox(
                    value: isSelected,
                    onChanged: (val) {
                      setState(() {
                        if (val == true) {
                          _selectedUserIds.add(uid);
                        } else {
                          _selectedUserIds.remove(uid);
                        }
                      });
                    },
                  ),
                  onTap: () {
                    setState(() {
                      if (isSelected) {
                        _selectedUserIds.remove(uid);
                      } else {
                        _selectedUserIds.add(uid);
                      }
                    });
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
